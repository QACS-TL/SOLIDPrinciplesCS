namespace OpenClosedPrinciple
{
    public enum CustomerType
    {
        Silver,
        Gold
    }
}