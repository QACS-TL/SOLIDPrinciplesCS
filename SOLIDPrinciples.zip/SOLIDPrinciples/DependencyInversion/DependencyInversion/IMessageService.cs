public interface IMessageService 
{
    void SendMessage();
}